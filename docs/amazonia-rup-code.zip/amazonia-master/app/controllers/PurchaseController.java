package controllers;

import models.Facade;
import models.entities.Address;
import models.entities.Payment;
import models.entities.Purchase;
import play.data.DynamicForm;
import play.data.Form;
import play.data.FormFactory;
import play.mvc.Result;
import views.html.purchaselist;

import javax.inject.Inject;
import java.util.Set;
import java.util.UUID;

import static play.mvc.Results.notFound;
import static play.mvc.Results.ok;


public class PurchaseController {
    private FormFactory formFactory;
    private Facade facade;

    @Inject
    public PurchaseController(FormFactory formFactory) {
        this.facade = Facade.getInstance();
        this.formFactory = formFactory;
    }

    public Result list() {
        Set<Purchase> setOfPurchase = facade.findAllPurchases();
        return ok(purchaselist.render(setOfPurchase));
    }

    public Result show(String id) throws Exception {
        if (id == null) {
            return notFound("Purchase not found!");
        }
        Purchase purchase = facade.findPurchaseById(id);
        if (purchase == null) {
            return notFound("Purchase not found!");
        }
        Form<Purchase> purchaseForm = formFactory.form(Purchase.class).fill(purchase);
        Form<Payment> paymentForm = formFactory.form(Payment.class).fill(purchase.getPayment());
        Form<Address> addressForm = formFactory.form(Address.class).fill(purchase.getDeliveryAddress());

        return ok(views.html.showpurchase.render(purchaseForm, paymentForm, addressForm));
    }


    public Result showBlank() {
        Form<Purchase> purchaseForm = formFactory.form(Purchase.class);
        Form<Payment> paymentForm = formFactory.form(Payment.class);
        Form<Address> addressForm = formFactory.form(Address.class);
        return ok(views.html.showpurchase.render(purchaseForm, paymentForm, addressForm));
    }

    public Result save() {
        DynamicForm requestData = formFactory.form().bindFromRequest();
        String textAddress = requestData.get("address");
        String deliveryType = requestData.get("deliveryType");
        String cardNumber = requestData.get("cardNumber");

        Payment payment = new Payment();
        payment.cardNumber = cardNumber;

        Purchase purchase = new Purchase();
        purchase.setDeliveryAddress(new Address(textAddress));
        purchase.setDeliveryType(deliveryType);
        purchase.setPayment(payment);
        purchase.setId(UUID.randomUUID().toString());

        facade.createPurchase(purchase);

        return list();
    }

}
