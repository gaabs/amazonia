package models.controls;

import models.collections.PurchaseCollection;
import models.entities.Purchase;

import java.util.Set;

public class PurchaseControl {
    private PurchaseCollection purchaseCollection;

    public PurchaseControl(PurchaseCollection purchaseCollection){
        this.purchaseCollection = purchaseCollection;
    }

    public boolean create(Purchase purchase){ return purchaseCollection.createPurchase(purchase);}
    public void delete(Purchase purchase){purchaseCollection.deletePurchase(purchase);}
    public boolean update(Purchase purchase) throws Exception {
        return purchaseCollection.updatePurchase(purchase);
    }
    public Set<Purchase> findAll(){return purchaseCollection.findAll();}
    public Purchase findById(String id) throws Exception {return purchaseCollection.findById(id);}
}
