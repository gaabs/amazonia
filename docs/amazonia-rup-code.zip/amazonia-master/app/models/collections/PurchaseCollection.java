package models.collections;

import models.entities.Purchase;
import models.repositories.IPurchaseRepository;
import models.repositories.PurchaseRepository;

import java.util.Set;

public class PurchaseCollection {
    private IPurchaseRepository purchaseRepository;

    public PurchaseCollection(IPurchaseRepository rep){
        this.purchaseRepository = rep;
    }

    public boolean createPurchase(Purchase purchase){ return purchaseRepository.createPurchase(purchase);}
    public void deletePurchase(Purchase purchase){purchaseRepository.deletePurchase(purchase);}
    public boolean updatePurchase(Purchase purchase)throws Exception{
        if(!purchaseRepository.updatePurchase(purchase)){
            throw new Exception("Compra inexistente!");
        }
        return true;
    }
    public Purchase findById(String id) throws Exception {
        Purchase ret = purchaseRepository.findById(id);
        if(ret == null){
            throw new Exception("Compra inexistente!");
        }
        return ret;
    }
    public Set<Purchase> findAll(){return purchaseRepository.findAll();}
}
