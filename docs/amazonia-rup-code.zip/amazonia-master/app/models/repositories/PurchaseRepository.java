package models.repositories;

import models.entities.Purchase;

import java.util.HashSet;
import java.util.Set;

public class PurchaseRepository implements IPurchaseRepository{
    Set<Purchase> purchases;

    public PurchaseRepository(){purchases = new HashSet<Purchase>();}

    public Set<Purchase> findAll(){return new HashSet<>(purchases);}

    public boolean createPurchase(Purchase purchase){
        purchases.add(purchase);
        return true;
    }

    public void deletePurchase(Purchase purchase){purchases.remove(purchase);}

    public boolean updatePurchase(Purchase purchase){
        Purchase aux = findById(purchase.getId());
        if(aux == null)return false;
        aux.setPayment(purchase.getPayment());
        aux.setDeliveryAddress(purchase.getDeliveryAddress());
        aux.setProductList(purchase.getProductList());
        aux.setStatus(purchase.getStatus());
        return true;
    }

    public Purchase findById(String id){
        for(Purchase purchase : purchases){
            if(purchase.getId().equals(id)){
                return purchase;
            }
        }
        return null;
    }
}
