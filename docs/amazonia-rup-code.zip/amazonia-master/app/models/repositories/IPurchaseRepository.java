package models.repositories;

import models.entities.Purchase;

import java.util.Set;

public interface IPurchaseRepository {

    Set<Purchase> findAll();

    boolean createPurchase(Purchase purchase);

    void deletePurchase(Purchase purchase);

    boolean updatePurchase(Purchase purchase);

    Purchase findById(String id);
}
