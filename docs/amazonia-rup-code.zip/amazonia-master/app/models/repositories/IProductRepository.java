package models.repositories;

import models.entities.Product;

import java.util.Set;

public interface IProductRepository {
    Set<Product> findAll();

    Product findById(Integer id);

    Set<Product> findByName(String term);

    boolean create(Product product);

    boolean delete(Product product);

    boolean update(Product product);
}
