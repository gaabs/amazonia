package models.repositories;

import models.entities.User;

import java.util.Set;

public interface IUserRepository {

    Set<User> findAll();

    Set<User> findByName(String term);

    boolean create(User user);

    boolean delete(User user);

    boolean update(User user);

    User findByEmail(String email);
}
