package models.entities;

public class Category {
    public String name;

    public Category(String name) {
        this.name = name;
    }
}