package models.entities;

public class Cart {
}
