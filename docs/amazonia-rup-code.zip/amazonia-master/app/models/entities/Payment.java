package models.entities;

import java.util.Date;

public class Payment {
    public Date date;
    public Double value;
    public String cardNumber;
    public String status;

    public Payment(){}

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Double getValue() {
        return value;
    }

    public void setValue(Double value) {
        this.value = value;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Payment{" +
                "date=" + date +
                ", value=" + value +
                ", cardNumber='" + cardNumber + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
