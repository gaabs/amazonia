package models;

import models.collections.ProductCollection;
import models.collections.PurchaseCollection;
import models.collections.UserCollection;
import models.controls.ProductControl;
import models.controls.PurchaseControl;
import models.controls.UserControl;
import models.entities.Product;
import models.entities.Purchase;
import models.entities.User;
import models.repositories.*;

import java.util.Set;

public class Facade {
    private static Facade instance;
    private UserControl userControl;
    private ProductControl productControl;
    private PurchaseControl purchaseControl;

    private Facade() {
        IUserRepository userRepository = new UserRepository();
        UserCollection userCollection = new UserCollection(userRepository);
        userControl = new UserControl(userCollection);

        IProductRepository productRepository = new ProductRepository();
        ProductCollection productCollection = new ProductCollection(productRepository);
        productControl = new ProductControl(productCollection);

        IPurchaseRepository purchaseRepository = new PurchaseRepository();
        PurchaseCollection purchaseCollection = new PurchaseCollection(purchaseRepository);
        purchaseControl = new PurchaseControl(purchaseCollection);
    }

    public static Facade getInstance() {
        if (instance == null) {
            instance = new Facade();
        }
        return instance;
    }

    public Set<Product> findAllProducts() {
        return productControl.findAll();
    }

    public Product findProductById(Integer id) {
        return productControl.findById(id);
    }

    public boolean createProduct(Product product) {
        return productControl.create(product);
    }

    public Set<Product> findProducts(String name, String category) {
        return productControl.find(name, category);
    }

    public Set<User> userList() {
        return userControl.list();
    }

    public User findUserByEmail(String email) {
        return userControl.findByEmail(email);
    }

    public boolean createUser(User user) {
        return userControl.create(user);
    }

    public boolean login(User user) {
        return userControl.login(user.email, user.password);
    }

    public Set<Purchase> findAllPurchases() {
        return purchaseControl.findAll();
    }

    public Purchase findPurchaseById(String id) throws Exception {
        return purchaseControl.findById(id);
    }

    public boolean createPurchase(Purchase purchase) {
        return purchaseControl.create(purchase);
    }

    public boolean updatePurchase(Purchase purchase) throws Exception {
        return purchaseControl.update(purchase);
    }


}
