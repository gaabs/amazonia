# Create your views here.
from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader

from accounts import controller


def login(request):
    if request.method == 'GET':
        template = loader.get_template('login.html')
        context = {
            'current_name': request.session.get('email', ''),
        }
        return HttpResponse(template.render(context, request))
    elif request.method == 'POST':
        name = request.POST.get("name", "")
        email = request.POST.get("email", "")
        password = request.POST.get("password", "")
        if controller.login(email, password):
            request.session['email'] = email   
            return HttpResponseRedirect('/')
        else:
            return HttpResponseRedirect('/error')


def register(request):
    if request.method == 'GET':
        template = loader.get_template('register.html')
        context = {
            'current_name': request.session.get('email', ''),
        }
        return HttpResponse(template.render(context, request))
    elif request.method == 'POST':
        name = request.POST.get("name", "")
        email = request.POST.get("email", "")
        password = request.POST.get("password", "")
        if controller.register(name, email, password):
            request.session['email'] = email
            return HttpResponseRedirect('/')
        else:
            return HttpResponseRedirect('/error')
