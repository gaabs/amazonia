import requests


def login(email, password):
    result = requests.post("http://user-backend:5000/login/", data={'email': email, 'password': password})
    print(result.status_code, result.text)

    return result.status_code == 200


def register(name, email, password):
    result = requests.post("http://user-backend:5000/register/", data={'name': name,
                                                                       'email': email,
                                                                       'password': password})
    print(result.status_code, result.text)

    return result.status_code == 200
