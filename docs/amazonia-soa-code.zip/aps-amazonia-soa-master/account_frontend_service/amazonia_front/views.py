# Create your views here.
from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader


def index(request):
    template = loader.get_template('index.html')
    context = {
        'current_name': request.session.get('email', ''),
    }
    return HttpResponse(template.render(context, request))
