from pymongo import MongoClient
from flask import Flask, request, jsonify
from flask_api import status

app = Flask(__name__)
mongo_client = MongoClient('user-db:27017')
user_collection = mongo_client.user_db.user

@app.route('/')
def index():
	return "index"

@app.route('/user/<email>', methods = ['GET'])
def getSingleUser(email):
	if email == None:
		return 'GET User request must contain email', status.HTTP_400_BAD_REQUEST
	
	user = getUser(email)
	
	if user is None:
		return 'No user found with given email', status.HTTP_404_NOT_FOUND
		
	del user['_id']
	return jsonify(user)

@app.route('/user/', methods = ['POST'])
def user():
	name = request.form.get('name')
	email = request.form.get('email')
	password = request.form.get('password')
	
	if not name or not email or not password:
		return 'Create User POST request must contain name, email and password', status.HTTP_400_BAD_REQUEST
		
	user = getUser(email)
	
	if user is not None:
		return 'Already has user with given email!', status.HTTP_400_BAD_REQUEST
	
	registration_id = createUser({'name': name, 'email': email, 'password': password})
	if registration_id is None:
		return 'Internal error creating new user', status.HTTP_500_INTERNAL_SERVER_ERROR

	return 'Yay, successful user creation!'	
	
def getUsers():
	return list(user_collection.find())

def getUser(email):
	return user_collection.find_one({"email": email})

def createUser(user_data):
	return user_collection.insert(user_data)

if __name__ == '__main__':
	app.run(debug=True, host='0.0.0.0')