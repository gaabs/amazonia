import requests

from flask import Flask, request
from flask_api import status

app = Flask(__name__)

@app.route('/')
def index():
	return "index"

@app.route('/login/', methods = ['POST'])
def login():
	email = request.form.get('email')
	password = request.form.get('password')
	
	if email == None or password == None:
		return 'Login POST request must contain email and password', status.HTTP_400_BAD_REQUEST
	
	user = getUser(email)
	
	if user is None:
		return 'No user found with given email', status.HTTP_404_NOT_FOUND
		
	if user['password'] != password:
		return 'User and password do not match', status.HTTP_401_UNAUTHORIZED
	
	return 'Yay, successful login!'

@app.route('/register/', methods = ['POST'])
def register():
	name = request.form.get('name')
	email = request.form.get('email')
	password = request.form.get('password')
	
	if name == None or email == None or password == None:
		return 'Register POST request must contain name, email and password', status.HTTP_400_BAD_REQUEST
		
	user = getUser(email)
	
	if user is not None:
		return 'Already has user with given email!', status.HTTP_400_BAD_REQUEST
	
	registration_successful = createUser(name, email, password)
	if not registration_successful:
		return 'Internal error creating new user', status.HTTP_500_INTERNAL_SERVER_ERROR
	
	return 'Yay, successful registration!'

def getUser(email):
	result = requests.get("http://user-dao:5000/user/" + email)
	
	if result.status_code != status.HTTP_200_OK:
		return None

	return result.json()

def createUser(name, email, password):
	result = requests.post("http://user-dao:5000/user/", data={'name': name, 'email': email, 'password': password})
	
	return result.status_code == status.HTTP_200_OK

if __name__ == '__main__':
	app.run(debug=True, host='0.0.0.0')